
import 'package:flutter/material.dart';
import 'package:actividad_1/model/carro_model.dart';

class DetalleCarroView extends StatelessWidget {
  final Carro carro;

  const DetalleCarroView({super.key, required this.carro});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del Carro')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  carro.imagen,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.image, size: 80),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text('Placa: ${carro.placa}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('Conductor: ${carro.conductor}', style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
